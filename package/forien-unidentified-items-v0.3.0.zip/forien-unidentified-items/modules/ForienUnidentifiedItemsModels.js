export class MystifiedData {
}
